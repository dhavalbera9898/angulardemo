/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	//config.allowedContent = true;
    //config.extraAllowedContent = 'div(*)';
    //config.entities = false;
    //config.fillEmptyBlocks = false;
    //config.showContextMenuArrow = true;
	config.removeButtons = 'Save';
    //config.removePlugins = 'Print,Preview,Find,Replace,Save,ShowBlocks,About,Form,Checkbox,TextField,Textarea,Select,Button,ImageButton,HiddenField,Flash,Radio,Iframe';
   
   config.contentsCss = 'CenturyGothic.css';
config.font_names = 'CenturyGothic' + config.font_names;
	
	config.filebrowserUploadUrl = baseUrl +'/public/ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';
    config.filebrowserImageUploadUrl = baseUrl +'/public/ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';
    config.filebrowserFlashUploadUrl =  baseUrl +'/public/ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';
};

