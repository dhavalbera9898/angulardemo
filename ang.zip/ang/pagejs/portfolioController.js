app.controller('portfolioController',function($http,$scope) {

        $scope.ListModel = $.parseJSON($("#ListModel").val());
        $scope.ListModel.PageSizeArray = getPageSizeArray();

        $scope.portfolioList = [];


        $scope.portfolioListURL =  baseUrl + '/admin/portfoliolist';
       

        $scope.ListPager = new PagerModule("id","DESC");
        $scope.InfoList = function () {
        var pagermodel = {
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.portfolioList;
        var jsonData = angular.toJson({Data: pagermodel});

        AngularAjaxCall($http, $scope.portfolioListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.portfolioList = response.Data.Items;

                    if ($scope.portfolioList.length == 0) {
                        $('#nodata').show();
                    }else {
                        $('#nodata').hide();
                    }
                    $scope.ListPager.totalRecords = response.Data.TotalItems;
                }
            });
        };

        // For search records
        $scope.SearchRecords = function () { 
            CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
            $scope.ListPager.currentPage = 1;
            $scope.InfoList();
        };


        $scope.ListPager.getDataCallback = $scope.InfoList;
        $scope.ListPager.getDataCallback();


        // For Reset
        $scope.Reset = function () {
            $scope.ListModel.frontSearchModel.Search = '';
            $scope.SearchRecords();
        }

        // Page size Record Set
        $scope.SetPageSize = function () {
            $scope.ListPager.pageSize = $scope.PageRecord
        }


        $scope.setDeleteId = function(id){
            $scope.delHTML = id;
        }
        $scope.deleteData = function(id) {
            $url = baseUrl + '/admin/portfolio/delete';
            $scope.id=id;

            $scope.datas = [];
            $http({
                url: $url,
                method: "POST",
                params: {id: $scope.id}
            }).success(function(response) {
                $scope.SearchRecords();
                toastr.success('Record is successfully deleted.', 'Delete!');
            });

        };




});


