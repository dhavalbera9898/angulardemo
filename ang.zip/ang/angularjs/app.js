var app = angular.module('myApp', ["ngLoadingSpinner","angularUtils.directives.dirPagination","ui.tree"]);

app.config(function(paginationTemplateProvider){
    paginationTemplateProvider.setPath(window.baseUrl + '/dirPagination'); // Set dir-pagination blade or html file path
});




